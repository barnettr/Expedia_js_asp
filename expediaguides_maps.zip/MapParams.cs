using System;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using ExpediaDestinations.MapPointService;

namespace ExpediaDestinations
{
	public class MapParams
	{
		private NameValueCollection requestParams;
		private NameValueCollection configParams;

		//Declare constants to define the names of the parameters
		//in the URL query string.
		public const string ParamPushpin="PP";
		public const string ParamDataSource="DSN";
		public const string ParamViewHeightWidth="VHW";
		public const string ParamMapWidth="W";
		public const string ParamMapHeight="H";

		public MapParams(System.Web.UI.Page page)
		{
			requestParams=page.Request.Params;
			configParams=ConfigurationSettings.AppSettings;
		}

		//If there is a non-empty element with the given key defined 
		//in the page request, return it.
		//Otherwise, if there is an element with the given key in the 
		//Web.config file, return that.
		//Else, return an empty string.
		public string this[string key]
		{
			get
			{
				if (null!=requestParams[key] && requestParams[key].Length>0)
				{
					return requestParams[key];
				}
				if (null!=configParams[key] && configParams[key].Length>0)
				{
					return configParams[key];
				}
				return String.Empty;
			}
		}

		//Convert a given string to a double. If the string is not
		//a number or is null, return 0.
		private static double GetStringAsDouble(string number)
		{
			try
			{
				return Double.Parse(number);
			}
			catch (ArgumentNullException)
			{
				return 0;
			}
			catch (FormatException)
			{
				return 0;
			}
		}

		//Convert a given string to an int. If the string is not
		//a number or is null, return 0.
		private static int GetStringAsInt(string number)
		{
			try
			{
				return Int32.Parse(number);
			}
			catch (ArgumentNullException)
			{
				return 0;
			}
			catch (FormatException)
			{
				return 0;
			}
		}

		public string DataSource
		{
			get
			{
				return this[ParamDataSource];
			}
		}

		public int MapWidth
		{
			get
			{
				return GetStringAsInt(this[ParamMapWidth]);
			}
		}

		public int MapHeight
		{
			get
			{
				return GetStringAsInt(this[ParamMapHeight]);
			}
		}

		//Return the ViewByHeightWidth property for the map to be rendered.
		//The parameter that holds the value is assumed to be of the form
		//Latitude:Longitude:Height:Width.
		//If Height and Width aren't defined, they default to 1 and 1.
		//If Latitude and Longitude aren't defined, they default 
		//to 0 and 0.
		public ViewByHeightWidth View
		{
			get
			{
				ViewByHeightWidth retView=new ViewByHeightWidth();
				retView.CenterPoint=new LatLong();
				string[] vhw=this[ParamViewHeightWidth].Split(new char[] {':'});
				if (vhw.Length>=2)
				{
					retView.CenterPoint.Latitude=GetStringAsDouble(vhw[0]);
					retView.CenterPoint.Longitude=GetStringAsDouble(vhw[1]);
				}
				else
				{
					retView.CenterPoint.Latitude=0;
					retView.CenterPoint.Longitude=0;
				}
				if (vhw.Length>=4)
				{
					retView.Height=GetStringAsDouble(vhw[2]);
					retView.Width=GetStringAsDouble(vhw[3]);
				}
				else
				{
					retView.Height=1;
					retView.Width=1;
				}
				return retView;
			}
		}

		//Return the icon (pushpin) to display on the map.
		//The format of the pushpin is assumed to be in the form
		//Latitude:Longitude:IconName:Label:IconDataSource.
		//Only Latitude and Longitude are required. All other parameters
		//have default values.
		//If no pushpin is set in the query string, return null.
		public Pushpin Icon
		{
			get
			{
				Pushpin retP=new Pushpin();
				string[] pp=this[ParamPushpin].Split(new char[] {':'});
				if (pp.Length>=2)
				{
					retP.LatLong=new LatLong();
					retP.LatLong.Latitude=GetStringAsDouble(pp[0]);
					retP.LatLong.Longitude=GetStringAsDouble(pp[1]);
					if (pp.Length>=3)
					{
						retP.IconName=pp[2];
					}
					else
					{
						retP.IconName="32"; //Default to pink asterisk.
					}
					if (pp.Length>=4)
					{
						retP.Label=pp[3];
					}
					if (pp.Length>=5)
					{
						retP.IconDataSource=pp[4];
					}
					else
					{
						retP.IconDataSource="MapPoint.Icons";
					}
					return retP;
				}
				else
				{
					return null;
				}
			}
		}
	}

}
