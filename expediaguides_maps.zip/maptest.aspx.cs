using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ExpediaDestinations.MapPointService;

namespace ExpediaDestinations
{
	/// <summary>
	/// Summary description for _default.
	/// </summary>
	public class maptest : System.Web.UI.Page
	{
		
		//properties we will attempt to get from the query string
		private string custFirstName;
		private string destAirportTLA;
		private string travelRecordLocator;
		private DateTime arrivalDate;
		private DateTime departureDate;
		private bool hasFlightBooked;
		private bool hasCarBooked;
		private bool hasHotelBooked;
		private bool hasActivityBooked;

		private NameValueCollection configParams;
		private int imageWidth = 300;
		private int imageHeight = 300;
		
	
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			configParams = ConfigurationSettings.AppSettings;
			ParseRequestParams();

			if (destAirportTLA != "")
			{
				
				CreateMapSpec();
			}

		}

		private void ParseRequestParams()
		{
			custFirstName = (Request.Params["fname"] != null) ? Request.Params["fname"] : "";
			destAirportTLA = (Request.Params["tla"] != null) ? Request.Params["tla"] : "";
			travelRecordLocator = (Request.Params["trl"] != null) ? Request.Params["trl"] : "";

			string arrDate = Request.Params["arrdate"];
			if (arrDate != null && arrDate != "")
				arrivalDate = new DateTime(Int32.Parse(arrDate.Substring(0, 4)), Int32.Parse(arrDate.Substring(4, 2)), Int32.Parse(arrDate.Substring(6, 2)));

			string depDate = Request.Params["depdate"];
			if (depDate != null && depDate != "")
				departureDate = new DateTime(Int32.Parse(depDate.Substring(0, 4)), Int32.Parse(depDate.Substring(4, 2)), Int32.Parse(depDate.Substring(6, 2)));

			if (Request.Params["booked"] != null && Request.Params["booked"].Length != 4)
			{
				string[] bookings = Request.Params["booked"].Split();
				hasFlightBooked = (bookings[0] == "1") ? true : false;
				hasCarBooked = (bookings[1] == "1") ? true : false;
				hasHotelBooked = (bookings[2] == "1") ? true : false;
				hasActivityBooked = (bookings[3] == "1") ? true : false;
			}
			else 
			{
				hasFlightBooked = hasCarBooked = hasHotelBooked = hasActivityBooked = false;
			}
		}

		public string CustomerFirstName
		{
			get
			{
				return custFirstName;
			}
		}

		public string DestinationTLA
		{
			get
			{
				return destAirportTLA;
			}
		}

		private void CreateMapSpec()
		{
			
			//Create a new MapSpecification object to build the map.
			MapSpecification mapSpec = new MapSpecification();
			//Get the DataSource directly from mParams.
			mapSpec.DataSourceName = configParams["DSN"];
			//Set the view.
			mapSpec.Views = new MapView[1];
			mapSpec.Views[0] = View;

			/*
			//Set the pushpin (if applicable).
			Pushpin icon = mParams.Icon;
			if (null!=icon)
			{
				mapSpec.Pushpins=new Pushpin[1];
				mapSpec.Pushpins[0] = icon;
			}
			*/

			//Set the properties of the MapOptions object and
			//set the width and height properties of mParams.
			mapSpec.Options = new MapOptions();
			mapSpec.Options.ReturnType = MapReturnType.ReturnImage;
			mapSpec.Options.Format = new MapPointService.ImageFormat();
			mapSpec.Options.Format.MimeType = "image/gif";
			mapSpec.Options.Format.Width = imageWidth;
			mapSpec.Options.Format.Height = imageHeight;

			//Store the specification object for use when panning and zooming
			Session["myMapSpec"] = mapSpec;


		}

		public MapView View
		{
			get
			{
				ViewByHeightWidth retView = new ViewByHeightWidth();
				retView.CenterPoint = new LatLong();
				string[] vhw = {"47.5998037152528", "-122.334557970968"};
				if (vhw.Length>=2)
				{
					retView.CenterPoint.Latitude=GetStringAsDouble(vhw[0]);
					retView.CenterPoint.Longitude=GetStringAsDouble(vhw[1]);
				}
				else
				{
					retView.CenterPoint.Latitude=0;
					retView.CenterPoint.Longitude=0;
				}
				if (vhw.Length>=4)
				{
					retView.Height=GetStringAsDouble(vhw[2]);
					retView.Width=GetStringAsDouble(vhw[3]);
				}
				else
				{
					retView.Height=1;
					retView.Width=1;
				}
				return retView;
			}
		}

		//Convert a given string to a double. If the string is not
		//a number or is null, return 0.
		private static double GetStringAsDouble(string number)
		{
			try
			{
				return Double.Parse(number);
			}
			catch (ArgumentNullException)
			{
				return 0;
			}
			catch (FormatException)
			{
				return 0;
			}
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
