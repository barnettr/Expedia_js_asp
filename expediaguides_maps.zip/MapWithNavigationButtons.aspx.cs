using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using ExpediaDestinations.MapPointService;
using System.Web.Services.Protocols;

namespace ExpediaDestinations
{
	/// <summary>
	/// Summary description for MapWithNavigationButtons.
	/// </summary>
	public class MapWithNavigationButtons : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label labelLatitude;
		protected System.Web.UI.WebControls.Label labelLongitude;
		protected System.Web.UI.WebControls.Label labelViewByScale;
		protected System.Web.UI.WebControls.Label labelScale;
		protected System.Web.UI.WebControls.Label labelViewByHeightWidth;
		protected System.Web.UI.WebControls.Label labelHeight;
		protected System.Web.UI.WebControls.TextBox textCenterPointLatitude;
		protected System.Web.UI.WebControls.TextBox textCenterPointLongitude;
		protected System.Web.UI.WebControls.RadioButton radioScale;
		protected System.Web.UI.WebControls.TextBox textScale;
		protected System.Web.UI.WebControls.RadioButton radioHeightWidth;
		protected System.Web.UI.WebControls.TextBox textHeight;
		protected System.Web.UI.WebControls.Label labelWidth;
		protected System.Web.UI.WebControls.TextBox textWidth;
		protected System.Web.UI.WebControls.Label labelViewByBoundingBox;
		protected System.Web.UI.WebControls.RadioButton radioBoundingBox;
		protected System.Web.UI.WebControls.Label labelCoordA;
		protected System.Web.UI.WebControls.TextBox textBoundingBoxLatitudeA;
		protected System.Web.UI.WebControls.TextBox textBoundingBoxLongitudeA;
		protected System.Web.UI.WebControls.Label labelCoordB;
		protected System.Web.UI.WebControls.TextBox textBoundingBoxLatitudeB;
		protected System.Web.UI.WebControls.TextBox textBoundingBoxLongitudeB;
		protected System.Web.UI.WebControls.Button buttonBuildMap;
		protected System.Web.UI.WebControls.Button buttonNorth;
		protected System.Web.UI.WebControls.Button buttonSouth;
		protected System.Web.UI.WebControls.Button buttonEast;
		protected System.Web.UI.WebControls.Button buttonWest;
		protected System.Web.UI.WebControls.Button buttonZoomIn;
		protected System.Web.UI.WebControls.Button buttonZoomOut;
		protected System.Web.UI.WebControls.Image Map;
		protected System.Web.UI.HtmlControls.HtmlTable tableMapControls;
   

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}
        
	  public void MoveIn(Object sender, EventArgs e)
      {
         RenderMap(0,0,-.25);
      }
      
      public void MoveOut(Object sender, EventArgs e)
      {
         RenderMap(0,0,.25);
      }
      
      public void MoveWest(Object sender, EventArgs e)
      {
         RenderMap(-.25,0,0);
      }
      
      public void MoveEast(Object sender, EventArgs e)
      {
         RenderMap(.25,0,0);
      }
      
      public void MoveNorth(Object sender, EventArgs e)
      {
         RenderMap(0,.25,0);
      }
      
      public void MoveSouth(Object sender, EventArgs e)
      {
         RenderMap(0,-.25,0);
      }
      
      
      public void buttonBuildMap_Click(object sender, System.EventArgs e)
      {
  
         if (radioScale.Checked)
         {
            BuildMapViaScale();
         }
         else if (radioBoundingBox.Checked)
         {
            BuildMapViaBoundingBox();
         }
         else
         {		
            BuildMapViaHeightWidth();
         }
      }

      void BuildMapViaHeightWidth()
      {
         //Create a global object to initialize MapPoint .NET objects
         ExpediaDestinations.Global global = (ExpediaDestinations.Global)Context.ApplicationInstance;

          //Create and specify the view object
          ViewByHeightWidth[] myMapViews = new ViewByHeightWidth[1];
          myMapViews[0] = new ViewByHeightWidth();
          myMapViews[0].CenterPoint = new LatLong();
          myMapViews[0].CenterPoint.Latitude = System.Convert.ToDouble(textCenterPointLatitude.Text);
          myMapViews[0].CenterPoint.Longitude = System.Convert.ToDouble(textCenterPointLongitude.Text);
          myMapViews[0].Height = System.Convert.ToDouble(textHeight.Text);
          myMapViews[0].Width = System.Convert.ToDouble(textWidth.Text);

          //Set up the map options
          MapOptions myMapOptions = new MapOptions();
          myMapOptions.Format = new ImageFormat();
		  myMapOptions.ReturnType = MapReturnType.ReturnUrl;
          myMapOptions.Format.Height = System.Convert.ToInt32(textHeight.Text); 
          myMapOptions.Format.Width = System.Convert.ToInt32(textWidth.Text); 
         
          //Create a pushpin for the center of the map
          Pushpin[] myPushPins = new Pushpin[1];
          myPushPins[0] = new Pushpin();
          myPushPins[0].PinID = "pin0";
          myPushPins[0].Label = "CenterPoint";
          myPushPins[0].IconName = "0";
          myPushPins[0].IconDataSource = "MapPoint.Icons";
          myPushPins[0].LatLong = myMapViews[0].CenterPoint;

          // Set up the specification object
          MapSpecification mapSpec = new MapSpecification();
          mapSpec.Options = myMapOptions;
          mapSpec.Pushpins = myPushPins;
          mapSpec.Views = myMapViews;
          mapSpec.DataSourceName = "MapPoint.NA";

          
		  //Store the specification object for use when panning and zooming
		  //and then render the map
		  Cache["myMapSpec"] = mapSpec;

		  RenderMap(0, 0, 0);
      }
      
      void BuildMapViaBoundingBox()
      {

          //Create a global object to initialize MapPoint .NET objects
          ExpediaDestinations.Global global = (ExpediaDestinations.Global)Context.ApplicationInstance;

          //Set up the map options
          MapOptions myMapOptions = new MapOptions();
          myMapOptions.Format = new ImageFormat();
		  myMapOptions.ReturnType = MapReturnType.ReturnUrl;
          myMapOptions.Format.Height = 500;
          myMapOptions.Format.Width = 500;

          //Create a pushpin array to hold the points of the bounding box
          Pushpin[] myPushPins = new Pushpin[2];

          myPushPins[0] = new Pushpin();
          myPushPins[0].PinID = "pin0"; 
          myPushPins[0].Label = "Point (1)";
          myPushPins[0].IconName = "0";
          myPushPins[0].IconDataSource = "MapPoint.Icons";
          myPushPins[0].LatLong = new LatLong();
          myPushPins[0].LatLong.Latitude = System.Convert.ToDouble(textBoundingBoxLatitudeA.Text);
          myPushPins[0].LatLong.Longitude = System.Convert.ToDouble(textBoundingBoxLongitudeA.Text);

          myPushPins[1] = new Pushpin();
          myPushPins[1].PinID = "pin1";
          myPushPins[1].Label = "Point (2)";
          myPushPins[1].IconName = "0";
          myPushPins[1].IconDataSource = "MapPoint.Icons";
          myPushPins[1].LatLong = new LatLong();
          myPushPins[1].LatLong.Latitude = System.Convert.ToDouble(textBoundingBoxLatitudeB.Text);
          myPushPins[1].LatLong.Longitude = System.Convert.ToDouble(textBoundingBoxLongitudeB.Text);	


		  //Set up the bounding rectangle map view 
          ViewByBoundingRectangle[] myMapViews = new ViewByBoundingRectangle[1];
          myMapViews[0] = new ViewByBoundingRectangle();
          myMapViews[0].BoundingRectangle = new LatLongRectangle();
          myMapViews[0].BoundingRectangle.Northeast = myPushPins[0].LatLong;
          myMapViews[0].BoundingRectangle.Southwest = myPushPins[1].LatLong;

          // Set up the specification object
          MapSpecification mapSpec = new MapSpecification();
          mapSpec.Options = myMapOptions;
          mapSpec.Pushpins = myPushPins;
          mapSpec.Views = myMapViews;
          mapSpec.DataSourceName = "MapPoint.NA";

          
          //Store the specification object for use when panning and zooming
		  //and then render the map
		  Cache["myMapSpec"] = mapSpec;

		  RenderMap(0, 0, 0);

      }
     
      void BuildMapViaScale()
      {
        
          // Create a global object to initialize MapPoint .NET objects
          ExpediaDestinations.Global global = (ExpediaDestinations.Global)Context.ApplicationInstance;

          //Use the scale to get a map
          ViewByScale[] myMapViews = new ViewByScale[1];
          myMapViews[0] = new ViewByScale();
          myMapViews[0].CenterPoint = new LatLong();
          myMapViews[0].CenterPoint.Latitude = System.Convert.ToDouble(textCenterPointLatitude.Text);
          myMapViews[0].CenterPoint.Longitude = System.Convert.ToDouble(textCenterPointLongitude.Text);
          myMapViews[0].MapScale = System.Convert.ToDouble(textScale.Text);

		  //Set up the map options
          MapOptions myMapOptions = new MapOptions();
		  myMapOptions.ReturnType = MapReturnType.ReturnUrl;
          myMapOptions.Format = new ImageFormat();
          myMapOptions.Format.Height = 500;
          myMapOptions.Format.Width = 500;


		  //Create a pushpin for the center of the map
          Pushpin[] myPushPins = new Pushpin[1];
          myPushPins[0] = new Pushpin();
          myPushPins[0].PinID = "pin0";
          myPushPins[0].Label = "CenterPoint";
          myPushPins[0].IconName = "0";
          myPushPins[0].IconDataSource = "MapPoint.Icons";
          myPushPins[0].LatLong = myMapViews[0].CenterPoint;


          // Set up the specification object
          MapSpecification mapSpec = new MapSpecification();
          mapSpec.Options = myMapOptions;
          mapSpec.Pushpins = myPushPins;
          mapSpec.Views = myMapViews;
          mapSpec.DataSourceName = "MapPoint.NA";


          //Store the specification object for use when panning and zooming
		  //and then render the map
		  Cache["myMapSpec"] = mapSpec;

		  RenderMap(0, 0, 0);

      }


		void RenderMap(double myPanHorizontalAdjustment, double myPanVerticalAdjustment, double myZoomValue) 
		{

			//Create a global object to initialize MapPoint .NET objects
			ExpediaDestinations.Global global = (ExpediaDestinations.Global)Context.ApplicationInstance;

			//Get the latest map specification object
			MapSpecification mapSpec = (MapSpecification)Cache["myMapSpec"];

			//Pan or zoom the map as appropriate
			mapSpec.Options.PanHorizontal = mapSpec.Options.PanHorizontal + myPanHorizontalAdjustment;
			mapSpec.Options.PanVertical = mapSpec.Options.PanVertical + myPanVerticalAdjustment;

			if (!(mapSpec.Options.Zoom + myZoomValue <= 0))
			{
				mapSpec.Options.Zoom = mapSpec.Options.Zoom + myZoomValue;
			}

            
			//Declare the map image array and get the map
			MapImage[] myMapImages;

			try
			{
				myMapImages = global.RenderService.GetMap(mapSpec);

				//Assign the Map Url
				this.Map.ImageUrl = myMapImages[0].Url;
				this.Map.Visible = true;
				

				//Also restore the changed map specification
				Cache["myMapSpec"] = mapSpec;
			}
			catch(SoapException myException)
			{
				//Your exception handling goes here
			}
        
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.buttonBuildMap.Click += new System.EventHandler(this.buttonBuildMap_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
	}
}
