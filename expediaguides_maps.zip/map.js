var zoom = 1;
var zoomLevel = 6;
var panDivisor = 4;

var panAmount = zoom / panDivisor;
var zoomScale = 2;

var vertDist = 0;
var horizDist = 0;

var zoom_fd = 1;
var zoomLevel_fd = 6;
var panDivisor_fd = 4;

var panAmount_fd = zoom_fd / panDivisor_fd;
var zoomScale_fd = 2;

var vertDist_fd = 0;
var horizDist_fd = 0;

function panN(map)
{
	if (map == 'fundesk')
		vertDist_fd += panAmount_fd;
	else
		vertDist += panAmount;
		
	setImage(map);
}

function panNW(map)
{
	if (map == 'fundesk')
	{
		vertDist_fd += panAmount_fd;
		horizDist_fd -= panAmount_fd;
	}
	else
	{
		vertDist += panAmount;
		horizDist -= panAmount;
	}	
	setImage(map);
}
function panNE(map)
{
	if (map == 'fundesk')
	{
		vertDist_fd += panAmount_fd;
		horizDist_fd += panAmount_fd;
	}
	else
	{
		vertDist += panAmount;
		horizDist += panAmount;
	}
	setImage(map);
}

function panSouth(map)
{
	if (map == 'fundesk')
		vertDist_fd -= panAmount_fd;
	else
		vertDist -= panAmount;

	setImage(map);
}

function panSW(map)
{
	if (map == 'fundesk')
	{
		vertDist_fd -= panAmount_fd;
		horizDist_fd -= panAmount_fd;
	}
	else
	{
		vertDist -= panAmount;
		horizDist -= panAmount;
	}
	setImage(map);
}
function panSE(map)
{
	if (map == 'fundesk')
	{
		vertDist_fd -= panAmount_fd;
		horizDist_fd += panAmount_fd;
	}
	else
	{
		vertDist -= panAmount;
		horizDist += panAmount;
	}
	setImage(map);
}

function panW(map)
{
	if (map == 'fundesk')
		horizDist_fd -= panAmount_fd;
	else
		horizDist -= panAmount;
	
	setImage(map);
}

function panE(map)
{
	if (map == 'fundesk')
		horizDist_fd += panAmount_fd;
	else
		horizDist += panAmount;
	
	setImage(map);
}
function centerMap(map)
{
	if (map == 'fundesk')
	{
		vertDist_fd = 0;
		horizDist_fd = 0;
	}
	else
	{
		vertDist = 0;
		horizDist = 0;
	}
	setImage(map);
}

function zoomIn(map)
{
	var newZoom 
	if (map == 'fundesk')
	{
		if (zoomLevel_fd < 11)
		{
			newZoom = zoom_fd / zoomScale_fd;
			panAmount_fd = zoom_fd / panDivisor_fd;
			zoom_fd = newZoom;
			updateZoomLevel(1, map);
			setImage(map);
		}
	}
	else
	{
		if (zoomLevel < 11)
		{
			newZoom = zoom / zoomScale;
			panAmount = zoom / panDivisor;
			zoom = newZoom;
			updateZoomLevel(1, map);
			setImage(map);
		}
	}
}
function zoomOut(map)
{
	var newZoom 
	if (map == 'fundesk')
	{
		if (zoomLevel_fd > 1)
		{
			newZoom = zoom_fd * zoomScale_fd;
			panAmount = zoom_fd / panDivisor_fd;
			zoom_fd = newZoom;
			updateZoomLevel(-1, map);
			setImage(map);
		}
	}
	else
	{
		if (zoomLevel > 1)
		{
			newZoom = zoom * zoomScale;
			panAmount = zoom / panDivisor;
			zoom = newZoom;
			updateZoomLevel(-1, map);
			setImage(map);
		}
	}
}
function updateZoomLevel(val, map)
{
	if (map == 'fundesk')
	{
		zoomLevel_fd += val;
		document.images["zoomLevelFunDesk"].src = "images/mapcontrol_zoom" + zoomLevel_fd + ".gif";
	}
	else
	{
		zoomLevel += val;
		document.images["zoomLevelHotel"].src = "images/mapcontrol_zoom" + zoomLevel + ".gif";
	}

}
function setImage(map)
{
	var query;
	var mapUrl;
	if (map == 'fundesk')
	{
		query = "pv=" + vertDist_fd + "&ph=" + horizDist_fd + "&zoom=" + zoom_fd;
		mapUrl = "MapServer.aspx?&tla=" + tla + "&" + query + "&map=" + map;
		document.images["mapFunDesk"].src = mapUrl;
	}
	else
	{
		query = "pv=" + vertDist + "&ph=" + horizDist + "&zoom=" + zoom;
		mapUrl = "MapServer.aspx?&tla=" + tla + "&" + query + "&map=" + map;
		document.images["mapHotel"].src = mapUrl;
	}
}

function updatePrintMap(map)
{
	var query;
	var mapUrl;
	//printWin is the name of the popup as defined in common.js
	if (map == 'fundesk')
	{
		query = "pv=" + vertDist_fd + "&ph=" + horizDist_fd + "&zoom=" + zoom_fd;
		mapUrl = "MapServer.aspx?&tla=" + tla + "&" + query + "&map=" + map;
		printWin.document.images["mapFunDesk"].src = mapUrl;
	}
	else
	{
		query = "pv=" + vertDist + "&ph=" + horizDist + "&zoom=" + zoom;
		mapUrl = "MapServer.aspx?&tla=" + tla + "&" + query + "&map=" + map;
		printWin.document.images["mapHotel"].src = mapUrl;
	}
}

