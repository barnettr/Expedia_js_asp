using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ExpediaDestinations.MapPointService;

namespace ExpediaDestinations
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class MapServer : System.Web.UI.Page
	{
		
		
		//Declare constants to define the names of the parameters
		//in the URL query string.
		public const string PanHorizontal = "ph";
		public const string PanVertical = "pv";
		public const string Zoom = "zoom";
		
		public string this[string key]
		{
			get
			{
				if (null!=this.Request.Params[key] && this.Request.Params[key].Length>0)
				{
					return this.Request.Params[key];
				}
				return String.Empty;
			}
		}

		//private MapParams mParams;
		//Build a map based on query string parameters
		private MapImage GetMap(string sMap)
		{
			ExpediaDestinations.Global global = (ExpediaDestinations.Global)Context.ApplicationInstance;
			MapSpecification mapSpec;
			if (sMap == "fundesk")
				mapSpec = (MapSpecification)Session["myMapSpecFunDesk"];
			else
				mapSpec = (MapSpecification)Session["myMapSpec"];
			
			
			mapSpec.Options.PanHorizontal = GetStringAsDouble(this[PanHorizontal]);
			mapSpec.Options.PanVertical = GetStringAsDouble(this[PanVertical]);

			if (GetStringAsDouble(this[Zoom]) > 0)
			{
				mapSpec.Options.Zoom = GetStringAsDouble(this[Zoom]);
			}
			
			
			//Call MapPoint Web Service and return its corresponding MapImage
			return global.RenderService.GetMap(mapSpec)[0];
		}

		//Write the contents of a bitmap to a stream, in GIF format.
		private void WriteGifToStream(Bitmap image, Stream outStream)
		{
			image.Save(outStream,System.Drawing.Imaging.ImageFormat.Gif);
			image.Dispose();
		}

		//Write the contents of a bitmap to a stream, in PNG format.
		//Because PNG cannot be written to a non-seekable stream, an
		//intermediate MemoryStream object (which is seekable) is used.
		private void WritePngToStream(Bitmap image, Stream outStream)
		{
			MemoryStream writeStream=new MemoryStream();
			image.Save(writeStream,System.Drawing.Imaging.ImageFormat.Png);
			writeStream.WriteTo(outStream);
			image.Dispose();
		}

		//Convert a given string to a double. If the string is not
		//a number or is null, return 0.
		private static double GetStringAsDouble(string number)
		{
			try
			{
				return Double.Parse(number);
			}
			catch (ArgumentNullException)
			{
				return 0;
			}
			catch (FormatException)
			{
				return 0;
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			//Initialize the parameters from the query string.
			string sMap = Request.QueryString["map"];
			MapImage map = GetMap(sMap);
			MemoryStream imageStream = new MemoryStream(map.MimeData.Bits);
			Bitmap rawBitmap = new Bitmap(imageStream,false);
			//Code to modify the image will be added here
			//and the following line will be deleted.
			WriteGifToStream(rawBitmap,Response.OutputStream);
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
