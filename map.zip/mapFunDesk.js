var zoom_FD = 1;
var zoomLevel_FD = 6;
var panDivisor_FD = 4;

var panAmount_FD = zoom_FD / panDivisor_FD;
var zoomScale_FD = 2;

var vertDist_FD = 0;
var horizDist_FD = 0;


function panN_FD()
{
	vertDist_FD += panAmount_FD;
	setImage_FD();
}

function panNW_FD()
{
	vertDist_FD += panAmount_FD;
	horizDist_FD -= panAmount_FD;
	setImage_FD();
}
function panNE_FD()
{
	vertDist_FD += panAmount_FD;
	horizDist_FD += panAmount_FD;
	setImage_FD();
}

function panSouth_FD()
{
	vertDist_FD -= panAmount_FD;
	setImage_FD();
}

function panSW_FD()
{
	vertDist_FD -= panAmount_FD;
	horizDist_FD -= panAmount_FD;
	setImage_FD();
}
function panSE_FD()
{
	vertDist_FD -= panAmount_FD;
	horizDist_FD += panAmount_FD;
	setImage_FD();
}

function panW_FD()
{
	horizDist_FD -= panAmount_FD;
	setImage_FD();
}

function panE_FD()
{
	horizDist_FD += panAmount_FD;
	setImage_FD();
}
function centerMap_FD()
{
	vertDist_FD = 0;
	horizDist_FD = 0;
	setImage_FD();
}

function zoomIn_FD()
{
	if (zoomLevel_FD < 11)
	{
		var newZoom = zoom_FD / zoomScale_FD;
		panAmount_FD = zoom_FD / panDivisor_FD;
		zoom_FD = newZoom;
		updateZoomLevel_FD(1);
		setImage_FD();
	}
}
function zoomOut_FD()
{
	if (zoomLevel_FD > 1)
	{
		var newZoom = zoom_FD * zoomScale_FD;
		panAmount_FD = zoom_FD / panDivisor_FD;
		zoom_FD = newZoom;
		updateZoomLevel_FD(-1);
		setImage_FD();
	}
}
function updateZoomLevel_FD(val)
{
	zoomLevel_FD += val;
	document.images["zoomLevel"].src = "images/mapcontrol_zoom" + zoomLevel_FD + ".gif";
}
function setImage_FD()
{
	var query = "pv=" + vertDist_FD + "&ph=" + horizDist_FD + "&zoom=" + zoom_FD;
	var mapUrl = "MapServer.aspx?&tla=" + tla + "&" + query + "&map=fundesk";
	//alert(mapUrl);
	document.images["mapFunDesk"].src = mapUrl;
}

function updatePrintMap_FD()
{
	var query = "pv=" + vertDist_FD + "&ph=" + horizDist_FD + "&zoom=" + zoom_FD;
	var mapUrl = "MapServer.aspx?&tla=" + tla + "&" + query + "&map=fundesk";
	//printWin is the name of the popup as defined in common.js
	printWin.document.images["mapFunDesk"].src = mapUrl;
}

